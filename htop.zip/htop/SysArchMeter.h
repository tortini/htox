#ifndef HEADER_SysArchMeter
#define HEADER_SysArchMeter
/*
htop - SysArchMeter.h
(C) 2021 htop dev team
Released under the GNU GPLv2+, see the COPYING file
in the source distribution for its full text.
*/
#include "Meter.h"


extern const MeterClass SysArchMeter_class;

#endif
