#ifndef HEADER_AffinityPanel
#define HEADER_AffinityPanel
/*
htop - AffinityPanel.h
(C) 2004-2011 Hisham H. Muhammad
Released under the GNU GPLv2+, see the COPYING file
in the source distribution for its full text.
*/

#include "Affinity.h"
#include "Panel.h"
#include "ProcessList.h"


extern const PanelClass AffinityPanel_class;

Panel* AffinityPanel_new(ProcessList* pl, const Affinity* affinity, int* width);

Affinity* AffinityPanel_getAffinity(Panel* super, ProcessList* pl);

#endif
