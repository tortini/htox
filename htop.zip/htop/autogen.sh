#!/bin/sh
autoreconf --force --install --verbose -Wall
